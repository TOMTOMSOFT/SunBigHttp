//
//  SBHttp.h
//  SBHttp
//
//  Created by Kim Kim on 2023/03/26.
//


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>



NS_ASSUME_NONNULL_BEGIN

@interface SBHttp : NSObject


-(NSString*) encodeQuery:(NSString*)sURL;

-(void) get:(NSString*)sURL
        withParam:(NSDictionary*)dicParam
        callback:(void (^)(NSError* err, NSData* data))cb;

//-(void) postWith:(NSString*)sURL
//        withParam:(NSDictionary*)dicParam
//        contentType:(NSString*) sContentType
//        callback:(void (^)(NSError* err, NSData* data))cb;
//
//-(void) postFileWith:(NSString*)sURL
//        withParam:(NSDictionary*)dicParam
//        withAttach:(NSArray*)arrAttach
//        contentType:(NSString*) sContentType
//        callback:(void (^)(NSError* err, NSData* data))cb;

-(void) post:(NSString*)sURL
       withParam:(NSDictionary*)dicParam
       withAttach:(NSArray*)arrAttach
       contentType:(NSString*) sContentType
    callback:(void (^)(NSError* err, NSData* data))cb;

@end

NS_ASSUME_NONNULL_END
