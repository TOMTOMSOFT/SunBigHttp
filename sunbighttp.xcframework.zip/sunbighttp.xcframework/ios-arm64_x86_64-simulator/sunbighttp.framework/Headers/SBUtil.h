//
//  SBUtil.h
//  objchttp1
//
//  Created by Kim Kim on 2023/03/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SBUtil : NSObject


+ (NSString *)urlEncode:(NSString*)sText;
+ (NSString *)urlDecode:(NSString*)sText;

@end

NS_ASSUME_NONNULL_END
